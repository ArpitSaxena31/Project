package Abstraction;

abstract class Bank {
	abstract void RateOfInterest(); 

}
