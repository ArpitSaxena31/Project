package DiamondProblem;

 interface interface2 {

	public default void display() {
		System.out.println("inside display method of interface2");
	}
}
