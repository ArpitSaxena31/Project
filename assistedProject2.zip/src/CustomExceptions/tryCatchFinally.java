package CustomExceptions;



public class tryCatchFinally {

	void fun() throws Exception {
		System.out.println("inside fun method........");
		throw new Exception("Errrrrroooorrrrrrr");
	}
	
	
	public static void main(String[] args) {
		tryCatchFinally obj = new tryCatchFinally();
		try {
			obj.fun();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Some error occured...."+e);
		}
		finally {
			System.out.println("program ended successfully");
		}
	}
}
