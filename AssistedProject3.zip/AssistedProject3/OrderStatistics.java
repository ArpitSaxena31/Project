package com;
class Smallest
	{ 
	int Smallest(int ar[], int a, int b, int c) 
	    	{ 
	             		if (c > 0 && c <= b - a + 1) 
	        		{ 
	            			int p = random(ar, a, b); 
	            			if (p-a == c-1) 
	                			return ar[p]; 
	            			if (p-a > c-1) 
	                			return Smallest(ar, a, p-1, c); 
	            			return Smallest(ar, p+1, b, c-p+a-1); 
	        		} 
	        return Integer.MAX_VALUE; 
	    } 
	    void swap(int ar[], int i, int j) 
	    { 
	        int temp = ar[i]; 
	        ar[i] = ar[j]; 
	        ar[j] = temp; 
	    } 
	    int partition(int ar[], int a, int b) 
	    { 
	        int x = ar[b], i = a; 
	        for (int j = a; j <= b - 1; j++) 
	        { 
	            if (ar[j] <= x) 
	            { 
	                swap(ar, i, j); 
	                i++; 
	            } 
	        } 
	        swap(ar, i, b); 
	        return i; 
	    } 
	    int random(int ar[], int a, int b) 
	    { 
	        int n = b-a+1; 
	        int pivot = (int)(Math.random()) * (n-1); 
	        swap(ar, a + pivot, b); 
	        return partition(ar, a, b); 
	    } 
	}  
	public class OrderStatistics {
	
		public static void main(String[] args) {
			Smallest ob = new Smallest(); 
	        int ar[] = {9,5,3,1,8,6,0,7}; 
	        int n = ar.length,c = 4; 
	        System.out.println("Fourth smallest element in a list is "+ ob.Smallest(ar, 0, n-1, c)); 
	    }
	}