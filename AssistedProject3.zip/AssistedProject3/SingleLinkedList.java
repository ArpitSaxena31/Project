package com;
import java.io.*; 
public class SingleLinkedList {
        Node head;  
	    static class Node 
{ 
    		int data; 
    		Node next; 
    		Node(int d) 
    		{ 
        			data = d; 
        			next = null; 
    		} 
	} 

	public static SingleLinkedList insert(SingleLinkedList list, int data) 
	{ 
    		
    		Node new_node = new Node(data); 
    		new_node.next = null; 
		
    		if (list.head == null) 
            { 
        			list.head = new_node; 
    		} 
    		else 
               { 
        			
        			Node last = list.head; 
        			while (last.next != null) 
                    { 
            			last = last.next; 
        			} 
			
        			last.next = new_node; 
    		} 
    		return list; 
	} 
	public static void printList(SingleLinkedList list) 
	{	 
    		Node currNode = list.head; 
    		System.out.print("LinkedList: "); 
    		
    		while (currNode != null) 
             { 
        			System.out.print(currNode.data + " "); 
        			
        			currNode = currNode.next; 
    		} 
    		System.out.println(); 
	} 
	
	public static SingleLinkedList deleteByKey(SingleLinkedList list, int key) 
	{ 
    		Node currNode = list.head, prev = null; 
    		 if(currNode != null && currNode.data == key) 
          { 
        			list.head = currNode.next; 
        			System.out.println(key + " found and deleted"); 
        			return list; 
    		} 
    		while (currNode != null && currNode.data != key) 
            { 
        			prev = currNode; 
        			currNode = currNode.next; 
    		} 
    		if (currNode != null) 
{ 
        			prev.next = currNode.next; 
        			System.out.println(key + " found and deleted"); 
    		} 
    		if (currNode == null) 
{ 
        			System.out.println(key + " not found"); 
    		} 
    		return list; 
	} 
	
		
	
	
	private static void If(boolean b) {
		
		
	}
	public static void main(String[] args) 
	{ 
    		
    		SingleLinkedList lst = new SingleLinkedList(); 
    		
    		lst = insert(lst, 1); 
    		lst = insert(lst, 2); 
    		lst = insert(lst, 3); 
    		lst = insert(lst, 4); 
    		lst = insert(lst, 5); 
    		lst = insert(lst, 6); 
    		lst = insert(lst, 7); 
    		lst = insert(lst, 8); 
    		
    		printList(lst); 
    		
    		deleteByKey(lst, 1); 
    		
    		printList(lst); 
    		
    		deleteByKey(lst, 4); 
    		
    		printList(lst); 
    		
   		deleteByKey(lst, 10); 
    		
    		printList(lst); 
	} 
} 