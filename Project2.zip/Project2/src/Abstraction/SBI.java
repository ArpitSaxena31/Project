package Abstraction;

public class SBI extends Bank {

	int x=7;
	@Override
	void RateOfInterest() {
		// TODO Auto-generated method stub
		System.out.println("Rate of interest in SBI is: "+x);
	}

}
