package thread;

public class SleepWait {
	
    private static Object ab = new Object();
   public static void main(String args[]) throws InterruptedException
   {
       Thread.sleep(1000);
       System.out.println("A thread '" + Thread.currentThread().getName() + "' is woken after sleeping for 1 second");
       synchronized (ab) 
       {
           ab.wait(1000);
           System.out.println(" And Object '" + ab + "' is woken after" + " waiting for 1 second");
       }
   }
}