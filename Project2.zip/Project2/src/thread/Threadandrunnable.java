package thread;


public class Threadandrunnable extends Thread implements Runnable {
	public static int Count = 0;
    public Threadandrunnable()
    {
    }
	public void run1()
 	{
  		System.out.println("Thread Implementation..concurrent thread started running");
     }
	
	public void run2() {
	        while(Threadandrunnable.Count <= 10){
	            try{
	                System.out.println("First Thread: "+(++Threadandrunnable.Count));
	                Thread.sleep(100);
	            } catch (InterruptedException iex) {
	                System.out.println("Exception in thread: "+iex.getMessage());
	            }
	        }
	    }
	    
	public static void main(String[] args) {
		Threadandrunnable mt = new  Threadandrunnable();
  		mt.start();
  		mt.run1();
  		System.out.println("\n Below is a Runnable Implementation output:-");
  		System.out.println("\nMain Thread Started");
        Threadandrunnable mrt = new Threadandrunnable();
        Thread t = new Thread(mrt);
        t.start();
        while(Threadandrunnable.Count <= 10)
        {
            try
            {
                System.out.println("Main Thread: "+(++Threadandrunnable.Count));
                Thread.sleep(100);
            } catch (InterruptedException iex)
            {
                System.out.println("Exception in main thread: "+iex.getMessage());
            }
        }
        System.out.println("\nMain Thread Ended");
    }
}