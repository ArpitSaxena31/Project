package Encapsulation;

public class encapsulationTest {

	public static void main(String[] args) {
		encapsulation obj = new encapsulation();
		obj.setName("Martin");
		System.out.println(obj.getName());
	}
}
